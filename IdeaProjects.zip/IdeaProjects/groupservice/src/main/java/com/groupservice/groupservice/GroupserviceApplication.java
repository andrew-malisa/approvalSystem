package com.groupservice.groupservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GroupserviceApplication {

    public static void main(String[] args) {
        SpringApplication.run(GroupserviceApplication.class, args);
    }

}
