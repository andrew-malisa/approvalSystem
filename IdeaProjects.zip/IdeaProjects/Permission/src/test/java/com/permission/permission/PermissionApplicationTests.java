package com.permission.permission;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PermissionApplicationTests {

    @Test
    void contextLoads() {
    }

}
